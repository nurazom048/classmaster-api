/*
  Warnings:

  - You are about to drop the column `accountId` on the `Routine` table. All the data in the column will be lost.
  - Added the required column `autoDeleteAt` to the `Summary` table without a default value. This is not possible if the table is not empty.

*/
-- AlterTable
ALTER TABLE "Routine" DROP COLUMN "accountId";

-- AlterTable
ALTER TABLE "Summary" ADD COLUMN     "autoDeleteAt" TIMESTAMP(3) NOT NULL;
